/* This file is auto generated, version 202006082127 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#202006082127 SMP Mon Jun 8 21:30:38 UTC 2020"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 9.3.0 (Ubuntu 9.3.0-13ubuntu1), GNU ld (GNU Binutils for Ubuntu) 2.34"
