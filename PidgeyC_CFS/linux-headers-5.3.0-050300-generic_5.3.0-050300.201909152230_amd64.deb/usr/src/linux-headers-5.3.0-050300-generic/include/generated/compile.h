/* This file is auto generated, version 201909152230 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201909152230 SMP Sun Sep 15 22:32:54 UTC 2019"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "sita"
#define LINUX_COMPILER "gcc version 9.2.1 20190909 (Ubuntu 9.2.1-8ubuntu1)"
